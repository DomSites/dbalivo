<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:6:{s:9:"wafStatus";s:7:"enabled";s:30:"learningModeGracePeriodEnabled";i:0;s:7:"authKey";s:64:"bDwNF&DQ]h~+78E@v1jTE*;=.$R]p8DV.]Ok 3]8Ej!_<F+G%P)AC(?!wiJYC/qX";s:7:"version";s:5:"1.0.5";s:11:"wafDisabled";b:0;s:13:"attackDataKey";i:2558;}